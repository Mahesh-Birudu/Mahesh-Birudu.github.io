import { BaseWebComponent } from '@pnp/modern-search-extensibility';
import { ServiceScope } from '@microsoft/sp-core-library';
import { ProfileService } from '../services/ProfileService';
import { ProfileCardController } from '../ui/ProfileCardController';

const providers = new WeakMap<ServiceScope, ProfileService>();

export class ProfileCardWebComponent extends BaseWebComponent {
  private controller?: ProfileCardController;
  private generation = 0;
  public connectedCallback(): void {
    const generation = ++this.generation;
    const scope = this._serviceScope as ServiceScope;
    // PnP sets this scope while registering the component. A naked standalone element cannot authenticate.
    if (!scope) { this.status('Register the extensibility library in PnP Search Results before using this card.'); return; }
    scope.whenFinished(() => window.setTimeout(() => {
      if (!this.isConnected || generation !== this.generation) return;
      try {
        let provider = providers.get(scope);
        if (!provider) { provider = new ProfileService(scope); providers.set(scope, provider); }
        this.controller?.disconnect();
        this.controller = new ProfileCardController(this, provider);
        this.controller.connect();
      } catch {
        this.status('The profile service could not start. Check the deployed library version and API permissions.');
      }
    }, 0));
  }
  public disconnectedCallback(): void { this.generation++; this.controller?.disconnect(); this.controller = undefined; }
  private status(message: string): void {
    this.querySelectorAll<HTMLElement>('.js-profile-status').forEach(node => { node.textContent = message; });
  }
}


