import { Profile, ProfileProvider, normalizeIdentity, presenceDisplay } from '../models/Profile';

/** Enhances the HTML supplied by the Site Assets Handlebars template. No profile value is parsed as HTML. */
export class ProfileCardController {
  private generation = 0;
  private objectUrl?: string;
  private returnFocus?: HTMLElement;
  private dialog?: HTMLDialogElement;
  private presenceTimer?: number;
  private readonly click = (event: Event): void => {
    const target = event.target instanceof Element ? event.target : undefined;
    if (target?.closest('.js-profile-open')) this.open();
    if (target?.closest('.js-profile-close')) this.close();
    if (target?.closest('.js-profile-retry')) void this.load();
  };
  private readonly cancel = (): void => this.returnFocus?.focus();
  public constructor(private readonly host: HTMLElement, private readonly provider: ProfileProvider) {}
  public connect(): void {
    this.host.addEventListener('click', this.click);
    this.dialog = this.host.querySelector<HTMLDialogElement>('.js-profile-dialog') || undefined;
    this.dialog?.addEventListener('close', this.cancel);
    void this.load();
  }
  public disconnect(): void {
    window.clearTimeout(this.presenceTimer);
    this.generation++;
    this.close();
    this.dialog?.removeEventListener('close', this.cancel);
    this.host.removeEventListener('click', this.click);
    this.revokePhoto();
  }
  private text(selector: string, value: string): void {
    this.host.querySelectorAll<HTMLElement>(selector).forEach(node => { node.textContent = value; });
  }
  private state(loading: boolean, error?: string): void {
    this.host.setAttribute('aria-busy', String(loading));
    this.text('.js-profile-status', loading ? 'Loading profile…' : error || '');
    this.host.querySelectorAll<HTMLButtonElement>('.js-profile-open').forEach(button => { button.disabled = loading || Boolean(error); });
    this.host.querySelectorAll<HTMLElement>('.js-profile-retry').forEach(button => { button.hidden = !error; });
  }
  private async load(): Promise<void> {
    window.clearTimeout(this.presenceTimer);
    const generation = ++this.generation;
    this.state(true);
    this.revokePhoto();
    this.host.querySelectorAll<HTMLImageElement>('.js-profile-photo').forEach(image => { image.hidden = true; image.removeAttribute('src'); });
    this.host.querySelectorAll<HTMLElement>('.js-profile-initials').forEach(node => { node.hidden = false; });
    try {
      const identity = normalizeIdentity(this.host.getAttribute('data-user-id') || '');
      const profile = await this.provider.getProfile(identity);
      if (generation !== this.generation || !this.host.isConnected) return;
      this.render(profile);
      this.state(false);
      void this.refreshPresence(profile.id, generation);
      const blob = await this.provider.getPhoto(identity);
      if (!blob || generation !== this.generation || !this.host.isConnected) return;
      if (!blob.type.startsWith('image/')) return;
      this.objectUrl = URL.createObjectURL(blob);
      this.host.querySelectorAll<HTMLImageElement>('.js-profile-photo').forEach(image => {
        image.onload = () => { if (generation === this.generation) { image.hidden = false; this.host.querySelectorAll<HTMLElement>('.js-profile-initials').forEach(node => { node.hidden = true; }); } };
        image.onerror = () => { image.hidden = true; };
        image.src = this.objectUrl!;
      });
    } catch (error) {
      if (generation !== this.generation || !this.host.isConnected) return;
      this.state(false, error instanceof Error ? error.message : 'The profile could not be loaded.');
    }
  }
  private async refreshPresence(userId: string, generation: number): Promise<void> {
    let display = presenceDisplay();
    try {
      if (document.visibilityState !== 'hidden' && this.provider.getPresence) display = presenceDisplay(await this.provider.getPresence(userId));
    } catch { /* Missing consent, throttling and unsupported users are unknown, never offline. */ }
    if (generation !== this.generation || !this.host.isConnected) return;
    if (document.visibilityState !== 'hidden') {
      this.host.querySelectorAll<HTMLElement>('.js-profile-presence').forEach(node => {
        node.setAttribute('data-presence', display.state);
        node.setAttribute('aria-label', 'Teams status: ' + display.label);
      });
      this.text('.js-profile-presence-label', display.label);
    }
    if (this.provider.getPresence) this.presenceTimer = window.setTimeout(() => { void this.refreshPresence(userId, generation); }, 60000);
  }
  private render(profile: Profile): void {
    const values: Record<string, string> = {
      name: profile.displayName || 'Unnamed user', title: profile.jobTitle || 'Job title not provided',
      email: profile.mail || profile.userPrincipalName || '',
      phone: profile.businessPhones?.filter(Boolean).join(', ') || profile.mobilePhone || '',
      company: profile.companyName || '', department: profile.department || '', mobile: profile.mobilePhone || '',
      office: profile.officeLocation || '', upn: profile.userPrincipalName || '',
      address: [profile.streetAddress, profile.city, profile.state, profile.postalCode, profile.country].filter(Boolean).join(', ')
    };
    Object.keys(values).forEach(key => this.text('.js-profile-' + key, values[key] || 'Not provided'));
    this.text('.js-profile-initials', values.name.split(/\s+/).slice(0, 2).map(part => part[0]).join('').toUpperCase());
    this.host.querySelectorAll<HTMLAnchorElement>('.js-profile-email-link').forEach(link => {
      const email = values.email;
      if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) { link.href = 'mailto:' + encodeURIComponent(email); link.removeAttribute('aria-disabled'); }
      else { link.removeAttribute('href'); link.setAttribute('aria-disabled', 'true'); }
    });
    this.host.querySelectorAll<HTMLButtonElement>('.js-profile-open').forEach(button => button.setAttribute('aria-label', 'View profile for ' + values.name));
  }
  private open(): void {
    if (!this.dialog || this.dialog.open) return;
    this.returnFocus = document.activeElement instanceof HTMLElement ? document.activeElement : undefined;
    this.dialog.showModal();
  }
  private close(): void { if (this.dialog?.open) this.dialog.close(); }
  private revokePhoto(): void { if (this.objectUrl) { URL.revokeObjectURL(this.objectUrl); this.objectUrl = undefined; } }
}
