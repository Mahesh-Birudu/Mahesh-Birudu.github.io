import { test } from 'node:test';
import assert from 'node:assert/strict';
import { JSDOM } from 'jsdom';
import Handlebars from 'handlebars';
import { readFileSync } from 'node:fs';
import { normalizeIdentity, ProfileError, ProfileProvider, presenceDisplay } from '../src/models/Profile';
import { ProfileCardController } from '../src/ui/ProfileCardController';

test('normalizes membership claims and preserves guest UPNs', () => {
  assert.equal(normalizeIdentity('i:0#.f|membership|user@example.test'), 'user@example.test');
  assert.equal(normalizeIdentity('guest_example.com#EXT#@tenant.onmicrosoft.com'), 'guest_example.com#EXT#@tenant.onmicrosoft.com');
  assert.equal(normalizeIdentity('f79dc10a-801a-494c-b4e0-a30d7789ea57'), 'f79dc10a-801a-494c-b4e0-a30d7789ea57');
});
test('rejects missing, display-name and path identities', () => {
  for (const value of ['', 'Jenny Wilson', '../me', 'https://example.test', 'user@example.test/users', 'user@example.test?x=1']) assert.throws(() => normalizeIdentity(value));
});

const raw = readFileSync('templates/profile-cards.html', 'utf8').match(/<content id="data-content">([\s\S]*?)<\/content>/)![1];
function setup(provider: ProfileProvider, identity = 'person@example.test') {
  const html = Handlebars.compile(raw)({data:{items:[{AccountName:identity,PreferredName:'Search fallback'}]}});
  const dom = new JSDOM('<!doctype html><body>' + html + '</body>', {url:'https://example.test'});
  for (const name of ['window','document','HTMLElement','Element','HTMLDialogElement','Event','MouseEvent']) Object.defineProperty(globalThis,name,{value:(dom.window as unknown as Record<string,unknown>)[name],configurable:true,writable:true});
  const host=dom.window.document.querySelector('m365-profile-card') as unknown as HTMLElement;
  const controller=new ProfileCardController(host,provider);
  controller.connect();
  return {dom,host,controller};
}
const tick=async()=>{await new Promise(resolve=>setTimeout(resolve,10));};
test('presence distinguishes offline, unknown and Teams activities',()=>{
  assert.equal(presenceDisplay({availability:'Offline'}).state,'offline');
  assert.equal(presenceDisplay({availability:'Available'}).label,'Available (online)');
  assert.equal(presenceDisplay({availability:'Busy',activity:'InACall'}).label,'In a call');
  assert.equal(presenceDisplay({availability:'PresenceUnknown'}).state,'unknown');
  assert.equal(presenceDisplay().state,'unknown');
});
test('presence denial preserves the profile and never displays offline',async()=>{
  const provider:ProfileProvider={getProfile:async()=>({id:'one',displayName:'Person'}),getPhoto:async()=>undefined,getPresence:async()=>{throw new Error('403');}};
  const {host,controller}=setup(provider);await tick();
  assert.equal(host.querySelector('.js-profile-presence')!.getAttribute('data-presence'),'unknown');
  assert.equal(host.querySelector('.js-profile-presence-label')!.textContent,'Presence unavailable');
  assert.equal(host.querySelector<HTMLButtonElement>('.js-profile-open')!.disabled,false);
  controller.disconnect();
});
test('presence updates both card and popup and ignores disconnected responses',async()=>{
  let finish!:(value:{availability:string})=>void;
  const provider:ProfileProvider={getProfile:async()=>({id:'one',displayName:'Person'}),getPhoto:async()=>undefined,getPresence:()=>new Promise(resolve=>{finish=resolve;})};
  const {host,controller}=setup(provider);await tick();
  finish({availability:'Available'});await tick();
  assert.equal(host.querySelectorAll('[data-presence="available"]').length,2);
  controller.disconnect();
});
test('renders text safely, missing fields, and dialog open/close with focus return',async()=>{
  const malicious='<img src=x onerror=alert(1)>';
  const provider:ProfileProvider={getProfile:async()=>({id:'one',displayName:malicious,userPrincipalName:'person@example.test'}),getPhoto:async()=>undefined};
  const {host,controller}=setup(provider);await tick();
  assert.equal(host.querySelector('.js-profile-name')!.textContent,malicious);
  assert.equal(host.querySelector('.js-profile-name img'),null);
  assert.equal(host.querySelector('.js-profile-company')!.textContent,'Not provided');
  const dialog=host.querySelector('dialog')!;
  // jsdom has no native dialog implementation; browser QA verifies the native interaction.
  dialog.showModal=()=>{dialog.setAttribute('open','');};
  dialog.close=()=>{dialog.removeAttribute('open');dialog.dispatchEvent(new Event('close'));};
  const button=host.querySelector<HTMLButtonElement>('.js-profile-open')!;
  button.focus();button.click();assert.equal(dialog.open,true);
  host.querySelector<HTMLButtonElement>('.js-profile-close')!.click();assert.equal(dialog.open,false);
  assert.equal(document.activeElement,button);controller.disconnect();
});
test('access-denied errors are visible and retry can recover',async()=>{
  let allowed=false;
  const provider:ProfileProvider={getProfile:async()=>{if(!allowed)throw new ProfileError(403);return{id:'one',displayName:'Recovered'};},getPhoto:async()=>undefined};
  const {host,controller}=setup(provider);await tick();
  assert.match(host.querySelector('.js-profile-status')!.textContent!,/permissions/);
  assert.equal(host.querySelector<HTMLButtonElement>('.js-profile-open')!.disabled,true);
  allowed=true;host.querySelector<HTMLButtonElement>('.js-profile-retry')!.click();await tick();
  assert.equal(host.querySelector('.js-profile-name')!.textContent,'Recovered');
  assert.equal(host.querySelector<HTMLButtonElement>('.js-profile-open')!.disabled,false);controller.disconnect();
});
test('late responses cannot update a disconnected card',async()=>{
  let finish!:(value:{id:string;displayName:string})=>void;
  const provider:ProfileProvider={getProfile:()=>new Promise(resolve=>{finish=resolve;}),getPhoto:async()=>undefined};
  const {host,controller}=setup(provider);controller.disconnect();host.remove();finish({id:'one',displayName:'Late'});await tick();
  assert.equal(host.querySelector('.js-profile-name')!.textContent,'Search fallback');
});
test('Handlebars escapes malicious identity attributes and includes a no-results state',()=>{
  const rendered=Handlebars.compile(raw)({data:{items:[{AccountName:'x" onclick="alert(1)'}]}});
  const dom=new JSDOM(rendered);assert.equal(dom.window.document.querySelector('m365-profile-card')!.hasAttribute('onclick'),false);
  assert.match(Handlebars.compile(raw)({data:{items:[]}}),/No people found/);
});
test('template wires paging to the current PnP page and page size',()=>{
  const hbs=Handlebars.create();
  hbs.registerHelper('gt',function(this:unknown,a:number,b:number,options:Handlebars.HelperOptions){return a>b?options.fn(this):options.inverse(this);});
  const html=hbs.compile(raw)({data:{items:[],totalItemsCount:23},properties:{paging:{showPaging:true,itemsCountPerPage:10,pagingRange:5}},paging:{currentPageNumber:2}});
  const dom=new JSDOM(html);
  const pager=dom.window.document.querySelector('pnp-pagination')!;
  assert.equal(pager.getAttribute('data-total-items'),'23');
  assert.equal(pager.getAttribute('data-items-count-per-page'),'10');
  assert.equal(pager.getAttribute('data-current-page-number'),'2');
});
