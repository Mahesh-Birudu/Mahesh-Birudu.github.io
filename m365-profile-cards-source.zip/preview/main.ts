import { ProfileCardController } from '../src/ui/ProfileCardController';
import { MockProfileProvider } from './fixtures';
const provider = new MockProfileProvider();
class PreviewCard extends HTMLElement {
  private controller?: ProfileCardController;
  public connectedCallback(): void { this.controller = new ProfileCardController(this, provider); this.controller.connect(); }
  public disconnectedCallback(): void { this.controller?.disconnect(); }
}
customElements.define('m365-profile-card', PreviewCard);
