# Changes

## 1.0.1

- Match the deployed PnP Modern Search 4.16.0 release: SPFx runtime 1.20.0, extensibility 1.20.1, React and React DOM 17.0.1, and the Gulp build toolchain.
- Use PnPjs Graph 3.25.0 for the TypeScript 4.7 toolchain.
- Preserve the solution ID and library manifest ID; increment the package version to 1.0.1.0.
- Display a service-startup error if component initialization fails instead of leaving an indefinite loading message.
- Include PnP pagination in the external Handlebars template.
- Add a generated-manifest compatibility check for the dependency versions that caused the original library load failure.

The existing Metrics deployment is in the site collection app catalog. Its scope is to be preserved during replacement. Graph permissions are unchanged.

- Delay component initialization until child markup is present so paged cards retain working popups.

## 1.1.0
- Add periodically refreshed Teams presence to cards and profile popups, with explicit unknown and permission-denied fallback.
- Request Microsoft Graph Presence.Read.All; administrator approval required.
