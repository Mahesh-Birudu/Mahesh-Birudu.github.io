# Teams presence — version 1.1.0

The Handlebars template includes .js-profile-presence and .js-profile-presence-label in the card and popup. The registered SPFx component hydrates these hooks from Microsoft Graph /v1.0/users/{directory-object-id}/presence using PnPjs and the existing signed-in SharePoint context. Search results do not supply live Teams presence.

States: Available (online), Busy, Do not disturb, Away, Be right back, Offline / appear offline, and Presence unavailable. Calls, meetings, presenting and focusing use Graph activity labels. Offline is reported only when Graph explicitly returns Offline; it does not prove a device is disconnected because users can choose Appear offline.

Refresh: once per minute for connected cards. Hidden tabs skip requests; disconnected cards cancel timers. Graph failures, missing consent, throttling, unknown states and unsupported users display Presence unavailable without blocking profile details. This is periodically refreshed presence, not a real-time subscription.

Deployment:
1. Replace the existing Metrics app-catalog package with version 1.1.0.0, preserving the current site scope.
2. In SharePoint Admin Center > Advanced > API access, review the new Microsoft Graph Presence.Read.All request. A tenant administrator must approve it before other users' presence can load. This is a new permission to read users' Teams presence. No permission has been granted by this update.
3. Replace Site Assets/profile-cards.html with templates/profile-cards.html from this release and reload the page.
4. Check a known available user, an offline user, paging, and the popup. API permissions and live Teams presence have not been verified for this release.

No tenant IDs, passwords, application secrets or environment URLs are embedded in the runtime code.

References:
https://learn.microsoft.com/en-us/graph/api/presence-get?view=graph-rest-1.0
https://learn.microsoft.com/en-us/graph/api/resources/presence?view=graph-rest-1.0
