# Code review checklist

1. Verify the registered tag `m365-profile-card` matches the external template and that the manifest ID is stable.
2. Confirm selected profile fields are appropriate for your audience, including address and mobile in the popup. Remove any unnecessary fields from the Graph projection and template before deploying.
3. Confirm delegated Graph consent is acceptable for each target tenant. No password or application secret should appear in source, config, build output, or templates.
4. Confirm the PnP Modern Search/SPFx versions in your tenant match this build target.
5. Review identity mapping for your people-search schema: AccountName/UPN or object ID, with claim normalization and URL encoding. Email aliases and numeric SharePoint user IDs are not valid replacements.
6. Verify all directory strings enter the DOM through `textContent`; Handlebars attributes use normal escaped expressions, not triple braces. The controller does not fetch arbitrary URLs supplied in HTML.
7. Review the one-minute, bounded, in-memory caching and the component lifecycle guards. Failed profile fetches are not cached; photo failures fall back to initials.
8. Verify keyboard behavior, long names, missing fields, tenant permission errors, search paging and multiple Search Results instances with the installed PnP release.
9. Keep the local preview's synthetic provider separate from the SPFx entry point. Never expose this authenticated directory solution through public GitHub Pages.
10. Only after approval, build/install the package, approve APIs, upload the Site Assets template, register the library, and complete tenant acceptance tests in SETUP.md.
